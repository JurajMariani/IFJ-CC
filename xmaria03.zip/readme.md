# IFJ Project 2021

 AUTHORS
 ------------------
 
 TEAM #141
 - xmaria03 Juraj Mariani
 - xmacej03 Lukas Macejka
 - xlukac16 Tomas Lukac
 - xhoril01 Denis Horil

 LICENSE
 -----------------

 The program is distributed under a GNU General Public License v3.0
